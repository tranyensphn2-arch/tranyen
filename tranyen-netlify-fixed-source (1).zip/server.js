import fs from 'node:fs';
import http from 'node:http';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT) || 3000;

const contentTypes = {
  '.html': 'text/html; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
};

const server = http.createServer((request, response) => {
  const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);

  if (pathname === '/runtime-config.js' && process.env.FIREBASE_CONFIG_JSON) {
    try {
      const firebase = JSON.parse(process.env.FIREBASE_CONFIG_JSON);
      const runtime = { appId: 'so-tay-gvcn-7n', classId: '7n', firebase };
      response.writeHead(200, {
        'Content-Type': 'text/javascript; charset=utf-8',
        'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff',
      });
      response.end(`window.__GVCN_RUNTIME_CONFIG__ = ${JSON.stringify(runtime, null, 2)};\n`);
      return;
    } catch (error) {
      response.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
      response.end(`FIREBASE_CONFIG_JSON không hợp lệ: ${error.message}`);
      return;
    }
  }

  const requestedPath = pathname === '/' ? '/index.html' : pathname;
  const candidatePath = path.resolve(__dirname, `.${requestedPath}`);
  const safePath = candidatePath.startsWith(`${__dirname}${path.sep}`) ? candidatePath : null;
  const filePath = safePath && fs.existsSync(safePath) && fs.statSync(safePath).isFile()
    ? safePath
    : path.join(__dirname, 'index.html');

  response.writeHead(200, {
    'Content-Type': contentTypes[path.extname(filePath).toLowerCase()] || 'application/octet-stream',
    'X-Content-Type-Options': 'nosniff',
  });
  fs.createReadStream(filePath).pipe(response);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
});
