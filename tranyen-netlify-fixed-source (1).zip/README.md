# Sổ Tay GVCN 7N

Ứng dụng quản lý lớp học chạy trực tiếp trên trình duyệt, sẵn sàng lưu trên GitHub và triển khai bằng Netlify.

## Chạy trên máy

Yêu cầu Node.js 20 trở lên.

```bash
npm install
npm run dev
```

Mở `http://localhost:3000`.

## Kiểm tra và build

```bash
npm run check
npm run build
```

Thư mục triển khai được tạo tại `dist/`.

Để bật đăng nhập bảo mật và đồng bộ dữ liệu, làm theo [FIREBASE_SETUP.md](FIREBASE_SETUP.md).

## Đưa lên GitHub và Netlify

1. Đẩy toàn bộ thư mục dự án lên một repository GitHub.
2. Trong Netlify, chọn **Add new site → Import an existing project** và kết nối repository.
3. Netlify tự đọc `netlify.toml`; cấu hình chuẩn là:
   - Build command: `npm run build`
   - Publish directory: `dist`
4. Chọn **Deploy site**.

Không cần chạy `server.js` trên Netlify. Tệp này chỉ phục vụ việc chạy thử tại máy.

## Bảo mật và dữ liệu

- Mỗi người dùng có một tài khoản Firebase Authentication riêng.
- Vai trò được lưu trong Firestore và kiểm tra bằng `firestore.rules`.
- Một bộ dữ liệu lớp `7N` được đồng bộ cho các tài khoản đã cấp quyền.
- GVCN có sao lưu phiên bản, khôi phục và nhật ký thao tác.
- Nếu chưa cấu hình Firebase, ứng dụng khóa đăng nhập quản trị và hiển thị hướng dẫn thiết lập; không quay lại mật khẩu mặc định trong mã nguồn.
