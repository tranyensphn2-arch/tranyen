const runtimeConfig = window.__GVCN_RUNTIME_CONFIG__ || {};
const firebaseConfig = runtimeConfig.firebase;
const appId = runtimeConfig.appId || 'so-tay-gvcn-7n';
const classId = runtimeConfig.classId || '7n';

window.cloudAppId = appId;
window.cloudClassId = classId;
window.secureMode = Boolean(firebaseConfig?.apiKey && firebaseConfig?.projectId && firebaseConfig?.appId);
window.cloudReady = false;
window.cloudUser = null;
window.cloudMembership = null;

if (!window.secureMode) {
  window.useCloud = false;
  window.cloudReady = true;
  window.startApp?.();
} else {
  try {
    const [firebaseApp, firebaseAuth, firebaseFirestore] = await Promise.all([
      import('https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js'),
      import('https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js'),
      import('https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js'),
    ]);

    const { initializeApp } = firebaseApp;
    const {
      getAuth,
      onAuthStateChanged,
      sendPasswordResetEmail,
      signInWithEmailAndPassword,
      signOut,
    } = firebaseAuth;
    const {
      addDoc,
      collection,
      doc,
      getDoc,
      getDocs,
      getFirestore,
      limit,
      onSnapshot,
      orderBy,
      query,
      serverTimestamp,
      setDoc,
      writeBatch,
    } = firebaseFirestore;

    const app = initializeApp(firebaseConfig);
    const auth = getAuth(app);
    const db = getFirestore(app);
    const memberRef = uid => doc(db, 'artifacts', appId, 'members', uid);
    const stateRef = doc(db, 'artifacts', appId, 'classes', classId, 'state', 'main');
    const backupsRef = collection(db, 'artifacts', appId, 'classes', classId, 'backups');
    const auditRef = collection(db, 'artifacts', appId, 'classes', classId, 'auditLogs');
    const studentViewRef = studentId => doc(db, 'artifacts', appId, 'classes', classId, 'studentViews', String(studentId));

    const getMembership = async uid => {
      const snapshot = await getDoc(memberRef(uid));
      if (!snapshot.exists()) return null;
      return { id: snapshot.id, ...snapshot.data() };
    };

    window.cloudServices = {
      signIn: (email, password) => signInWithEmailAndPassword(auth, email, password),
      signOut: () => signOut(auth),
      resetPassword: email => sendPasswordResetEmail(auth, email),
      getMembership,
      subscribeState: (onData, onError) => onSnapshot(stateRef, onData, onError),
      subscribeStudentView: (studentId, onData, onError) => onSnapshot(studentViewRef(studentId), onData, onError),
      saveState: state => setDoc(stateRef, {
        state,
        updatedAt: new Date().toISOString(),
        updatedBy: auth.currentUser?.uid || '',
      }),
      saveStudentViews: async views => {
        const batch = writeBatch(db);
        views.slice(0, 450).forEach(view => {
          batch.set(studentViewRef(view.studentId), {
            state: view.state,
            updatedAt: new Date().toISOString(),
            updatedBy: auth.currentUser?.uid || '',
          });
        });
        await batch.commit();
      },
      createBackup: payload => addDoc(backupsRef, {
        ...payload,
        actorUid: auth.currentUser?.uid || '',
        serverCreatedAt: serverTimestamp(),
      }),
      listBackups: async (maxItems = 30) => {
        const snapshot = await getDocs(query(backupsRef, orderBy('createdAt', 'desc'), limit(maxItems)));
        return snapshot.docs.map(item => ({ id: item.id, source: 'cloud', ...item.data() }));
      },
      getBackup: async backupId => {
        const snapshot = await getDoc(doc(backupsRef, backupId));
        return snapshot.exists() ? { id: snapshot.id, source: 'cloud', ...snapshot.data() } : null;
      },
      addAudit: entry => addDoc(auditRef, {
        ...entry,
        actorUid: auth.currentUser?.uid || '',
        serverCreatedAt: serverTimestamp(),
      }),
      listAudit: async (maxItems = 100) => {
        const snapshot = await getDocs(query(auditRef, orderBy('createdAt', 'desc'), limit(maxItems)));
        return snapshot.docs.map(item => ({ id: item.id, source: 'cloud', ...item.data() }));
      },
    };

    window.useCloud = true;
    window.cloudDb = db;

    onAuthStateChanged(auth, async user => {
      let membership = null;
      let authError = '';

      if (user) {
        try {
          membership = await getMembership(user.uid);
          if (!membership?.active) authError = 'Tài khoản chưa được cấp quyền hoặc đã bị khóa.';
        } catch (error) {
          console.error('Membership lookup failed:', error);
          authError = 'Không thể kiểm tra quyền tài khoản.';
        }
      }

      window.cloudUser = user || null;
      window.cloudMembership = membership?.active ? membership : null;
      window.cloudReady = true;

      if (typeof window.handleCloudAuthState === 'function') {
        window.handleCloudAuthState(window.cloudUser, window.cloudMembership, authError);
      } else {
        window.startApp?.();
      }
    });
  } catch (error) {
    console.error('Secure Firebase initialization failed:', error);
    window.useCloud = false;
    // Giữ chế độ khóa an toàn: lỗi tải Firebase không được phép rơi về
    // cơ chế dữ liệu/mật khẩu cục bộ cũ.
    window.secureMode = true;
    window.cloudReady = true;
    window.cloudInitError = error?.message || 'Không thể khởi tạo Firebase.';
    window.startApp?.();
  }
}
