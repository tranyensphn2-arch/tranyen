import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const projectDir = path.resolve(scriptDir, '..');
const indexPath = path.join(projectDir, 'index.html');
const outputDir = path.join(projectDir, 'dist');
const firebaseScriptPath = path.join(projectDir, 'firebase-secure.js');
const checkOnly = process.argv.includes('--check');
const html = fs.readFileSync(indexPath, 'utf8');

const failures = [];

if (!html.trimStart().startsWith('<!DOCTYPE html>')) failures.push('Thiếu DOCTYPE HTML.');
if (!html.includes('</body>') || !html.includes('</html>')) failures.push('Thiếu thẻ đóng body/html.');
if (html.includes('\0')) failures.push('index.html chứa byte NUL bất thường.');

const openScripts = [...html.matchAll(/<script(?:\s[^>]*)?>/gi)];
const closeScriptCount = (html.match(/<\/script>/gi) || []).length;

if (openScripts.length !== closeScriptCount) {
  failures.push(`Số thẻ script mở/đóng không khớp (${openScripts.length}/${closeScriptCount}).`);
}

for (const [index, match] of openScripts.entries()) {
  const tag = match[0];
  if (/\bsrc\s*=/.test(tag)) continue;

  const codeStart = match.index + tag.length;
  const codeEnd = html.indexOf('</script>', codeStart);
  if (codeEnd === -1) continue;

  try {
    new vm.Script(html.slice(codeStart, codeEnd), { filename: `inline-script-${index + 1}.js` });
  } catch (error) {
    failures.push(error.stack || error.message);
  }
}

if (failures.length) {
  console.error(failures.join('\n\n'));
  process.exit(1);
}

const firebaseSyntax = spawnSync(process.execPath, ['--check', firebaseScriptPath], { encoding: 'utf8' });
if (firebaseSyntax.status !== 0) {
  console.error(firebaseSyntax.stderr || firebaseSyntax.stdout || 'firebase-secure.js không hợp lệ.');
  process.exit(1);
}

console.log('Kiểm tra cấu trúc HTML và cú pháp JavaScript: đạt.');

if (!checkOnly) {
  fs.rmSync(outputDir, { recursive: true, force: true });
  fs.mkdirSync(outputDir, { recursive: true });
  fs.copyFileSync(indexPath, path.join(outputDir, 'index.html'));
  fs.copyFileSync(path.join(projectDir, 'metadata.json'), path.join(outputDir, 'metadata.json'));
  fs.copyFileSync(firebaseScriptPath, path.join(outputDir, 'firebase-secure.js'));

  let runtimeConfig = {
    appId: 'so-tay-gvcn-7n',
    classId: '7n',
    firebase: null,
  };

  if (process.env.FIREBASE_CONFIG_JSON) {
    try {
      const firebase = JSON.parse(process.env.FIREBASE_CONFIG_JSON);
      const requiredKeys = ['apiKey', 'authDomain', 'projectId', 'appId'];
      const missingKeys = requiredKeys.filter(key => !firebase[key]);
      if (missingKeys.length) throw new Error(`Thiếu trường: ${missingKeys.join(', ')}`);
      runtimeConfig = { ...runtimeConfig, firebase };
    } catch (error) {
      console.error(`FIREBASE_CONFIG_JSON không hợp lệ: ${error.message}`);
      process.exit(1);
    }
  } else {
    console.warn('Chưa có FIREBASE_CONFIG_JSON: bản build sẽ hiển thị hướng dẫn cấu hình bảo mật.');
  }

  const runtimeSource = `window.__GVCN_RUNTIME_CONFIG__ = ${JSON.stringify(runtimeConfig, null, 2)};\n`;
  fs.writeFileSync(path.join(outputDir, 'runtime-config.js'), runtimeSource);
  console.log('Build Netlify hoàn tất tại dist/.');
}
