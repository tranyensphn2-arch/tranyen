window.__GVCN_RUNTIME_CONFIG__ = {
  appId: 'so-tay-gvcn-7n',
  classId: '7n',
  firebase: null,
};
